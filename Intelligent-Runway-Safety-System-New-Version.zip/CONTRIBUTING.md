# Contributing

This repository is primarily an academic mini-project.

If the project is extended:

1. Create a separate branch for the change.
2. Update the Arduino code and related documentation together.
3. Clearly document any new sensor, module, pin assignment, or logic change.
4. Test the hardware before submitting changes.
5. Update the README and relevant documentation.
6. Use a clear commit message.

Do not introduce RFID into the revised version unless it is intentionally documented as a future or alternate version.

[Back to README](README.md)
