# Documentation

Place the final project report, presentation, block diagram, and other academic documentation here.

Recommended files:

```text
Project_Report.pdf
Project_Presentation.pptx
Block_Diagram.png
```
