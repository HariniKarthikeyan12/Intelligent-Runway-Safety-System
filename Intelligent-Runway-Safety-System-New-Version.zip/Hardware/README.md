# Hardware

Place prototype photographs and hardware setup images in this folder.

Recommended filename:

```text
prototype_setup.jpg
```
