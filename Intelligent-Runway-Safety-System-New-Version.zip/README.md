# Dynamic Runway Safety Control System (DRSCS)

## Overview

The **Dynamic Runway Safety Control System (DRSCS)** is an Arduino Uno-based prototype designed to monitor runway entry and runway occupancy using ultrasonic and IR sensors.

The revised project version **removes RFID**. Instead of aircraft identification through RFID, the system uses sensor-based detection and Arduino decision-making to provide runway status indications and collision-prevention alerts.

### Main functions

- Detect an approaching object at the runway entry.
- Check runway occupancy using a second ultrasonic sensor.
- Use an IR sensor as an additional safety detection layer.
- Show system status using Green, Yellow, and Red LEDs.
- Activate a buzzer when the runway is occupied or an object is detected by the IR sensor.
- Display system information through the Arduino Serial Monitor.

> **Project version:** RFID-free revision of the original Dynamic Runway Safety Control System.

## Repository Structure

```text
Intelligent-Runway-Safety-System/
│
├── README.md
├── TABLE_OF_CONTENTS.md
├── LICENSE
├── CONTRIBUTING.md
│
├── Arduino_Code/
│   └── runway_safety.ino
│
├── docs/
│   ├── 01-project-identification.md
│   ├── 02-aim.md
│   ├── 03-problem-statement.md
│   ├── 04-components-required.md
│   ├── 05-construction.md
│   ├── 06-working.md
│   ├── 07-system-logic.md
│   ├── 08-code-description.md
│   ├── 09-testing-and-output.md
│   ├── 10-possible-advancements.md
│   └── 11-result.md
│
├── Hardware/
├── Circuit_Diagram/
├── Simulation/
└── Documentation/
```

## Hardware Components

| Component | Quantity |
|---|---:|
| Arduino Uno R3 | 1 |
| Breadboard | 1 |
| Jumper wires | Sufficient |
| HC-SR04 Ultrasonic Sensor | 2 |
| IR Sensor | 1 |
| Green LED | 1 |
| Yellow LED | 1 |
| Red LED | 1 |
| 220Ω Resistor | 3 |
| Buzzer | 1 |

**RFID reader and RFID tags are not used in this revised version.**

## Pin Configuration

| Device | Arduino Pin |
|---|---|
| Ultrasonic 1 TRIG | D2 |
| Ultrasonic 1 ECHO | D3 |
| Ultrasonic 2 TRIG | D4 |
| Ultrasonic 2 ECHO | D5 |
| IR Sensor | D6 |
| Green LED | D7 |
| Yellow LED | D8 |
| Red LED | A0 |
| Buzzer | A1 |

## Detection Threshold

The Arduino code uses:

```cpp
#define DETECTION_DISTANCE 20
```

An ultrasonic reading at or below **20 cm** is treated as an object detection.

## How the System Works

1. The entry ultrasonic sensor checks for an approaching object.
2. The runway ultrasonic sensor checks whether an object is present on the runway.
3. The IR sensor has priority in the current program.
4. If the IR sensor detects an object, the Red LED and buzzer are activated.
5. If an object approaches the entry sensor, the Yellow LED indicates that the runway is being checked.
6. If the runway is clear, the Green LED turns ON.
7. If the runway is occupied, the Red LED and buzzer turn ON.
8. The Serial Monitor displays the current detection and runway status.

## LED Status

| Status | Green | Yellow | Red | Buzzer |
|---|---|---|---|---|
| Waiting | OFF | OFF | OFF | OFF |
| Checking runway | OFF | ON | OFF | OFF |
| Runway clear | ON | OFF | OFF | OFF |
| Runway occupied / alert | OFF | OFF | ON | ON |

## Installation

### Arduino IDE

1. Install the Arduino IDE.
2. Open `Arduino_Code/runway_safety.ino`.
3. Connect the Arduino Uno to the computer using USB.
4. Select the correct Arduino board and COM/serial port.
5. Verify/compile the sketch.
6. Upload it to the Arduino Uno.
7. Open the Serial Monitor at **9600 baud**.

No external Arduino library is required by the supplied sketch.

## Usage

After uploading the program:

- Move an object toward the **Entry Ultrasonic Sensor**.
- The system enters the checking state.
- The second ultrasonic sensor is used to determine runway occupancy.
- A clear runway produces a Green LED indication.
- An occupied runway produces a Red LED and buzzer alert.
- The IR sensor can independently trigger the runway-occupied alert.

## Key Project Findings

The revised system demonstrates that runway entry and occupancy can be monitored using basic sensors and an Arduino controller. It provides local visual and audio alerts without requiring RFID hardware.

The prototype is intended as an educational model and does not replace certified airport runway safety, aircraft surveillance, or air traffic control systems.

## Future Scope

Possible improvements include:

- ESP32-CAM-based visual monitoring.
- Higher-range distance sensors.
- Wireless communication.
- Centralized runway monitoring.
- Integration with an appropriate monitoring dashboard.
- Improved object classification and multiple-zone detection.

## Project Documentation

Place the final project report, presentation, block diagram, circuit diagram, and prototype photographs in the appropriate folders.

## License

See [LICENSE](LICENSE).

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md).
