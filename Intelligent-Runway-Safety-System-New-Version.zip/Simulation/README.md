# Simulation

Place the simulation information here.

If using Wokwi, add the simulation URL to a file such as:

```text
wokwi_link.txt
```

Do not add a placeholder URL as if it were a real simulation.
