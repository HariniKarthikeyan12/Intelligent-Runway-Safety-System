# Table of Contents

1. [Project Identification](docs/01-project-identification.md)
2. [Aim](docs/02-aim.md)
3. [Problem Statement](docs/03-problem-statement.md)
4. [Components Required](docs/04-components-required.md)
5. [Construction of the Project](docs/05-construction.md)
6. [Working of the Project](docs/06-working.md)
7. [System Logic](docs/07-system-logic.md)
8. [Code Description](docs/08-code-description.md)
9. [Testing and Output](docs/09-testing-and-output.md)
10. [Possible Advancements](docs/10-possible-advancements.md)
11. [Result](docs/11-result.md)
