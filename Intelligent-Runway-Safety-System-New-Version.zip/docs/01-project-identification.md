# Project Identification

**ST. JOSEPH’S COLLEGE OF ENGINEERING**

**DIGITAL ELECTRONICS**

**Mini Project**

- **Subject Name:** Digital Electronics
- **Subject Code:** EC25202
- **Name:** Harini Karthikeyan
- **Roll No:** 25EC317
- **Register No:** 312325106056
- **Project Name:** Dynamic Runway Safety Control System (DRSCS)

## Revised Version

This repository documents the revised implementation in which **RFID has been removed**. The current prototype uses Arduino Uno, ultrasonic sensors, an IR sensor, LEDs, and a buzzer.

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
