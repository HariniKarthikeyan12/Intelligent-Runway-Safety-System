# Aim

The aim of the revised project is to design an intelligent runway safety prototype using an Arduino Uno board and basic sensors.

The system detects approaching objects and runway occupancy using ultrasonic and IR sensors and provides visual and audio alerts to help prevent unsafe runway entry and potential collisions.

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
