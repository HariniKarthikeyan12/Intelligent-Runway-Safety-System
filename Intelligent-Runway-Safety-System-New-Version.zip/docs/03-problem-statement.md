# Problem Statement

Runway incursions and unsafe runway occupancy can create serious safety risks. A low-cost educational prototype can demonstrate how automated sensing and decision-making may be used to monitor runway movement.

The revised project addresses this problem using two ultrasonic sensors and an IR sensor. One ultrasonic sensor monitors the runway entry, while the second checks runway occupancy. The IR sensor provides an additional detection layer. The Arduino processes these inputs and controls LEDs and a buzzer to indicate whether the runway is being checked, clear, or occupied.

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
