# Components Required

| S. No. | Component | Quantity |
|---:|---|---:|
| 1 | Arduino Uno R3 | 1 |
| 2 | Breadboard | 1 |
| 3 | Jumper wires | Sufficient amount |
| 4 | Ultrasonic Sensor (HC-SR04) | 2 |
| 5 | IR Sensor | 1 |
| 6 | Green LED | 1 |
| 7 | Yellow LED | 1 |
| 8 | Red LED | 1 |
| 9 | Resistors (220Ω) | 3 |
| 10 | Buzzer | 1 |

### Removed Components

The revised implementation does not use:

- RFID Reader Module (RC522)
- RFID Tags

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
