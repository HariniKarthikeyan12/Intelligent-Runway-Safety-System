# Construction of the Project

The runway prototype can be constructed using cardboard or foam board. The runway is divided conceptually into an entry area and a runway/occupancy area.

The Arduino Uno acts as the central controller and is connected to a breadboard for circuit organization.

Two ultrasonic sensors are positioned as follows:

- **Ultrasonic Sensor 1:** runway entry detection.
- **Ultrasonic Sensor 2:** runway/exit or occupancy detection.

An IR sensor is installed as an additional detection layer.

Green, Yellow, and Red LEDs provide visual status indications, while the buzzer provides an audio warning.

### Pin Connections

| Component | Arduino Pin |
|---|---|
| TRIG1 | D2 |
| ECHO1 | D3 |
| TRIG2 | D4 |
| ECHO2 | D5 |
| IR | D6 |
| GREEN | D7 |
| YELLOW | D8 |
| RED | A0 |
| BUZZER | A1 |

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
