# Working of the Project

The system works by continuously reading the entry ultrasonic sensor, runway ultrasonic sensor, and IR sensor.

## Step 1: Entry Detection

The first ultrasonic sensor measures the distance to an approaching object.

If the measured distance is greater than 0 cm and less than or equal to 20 cm, an object is considered detected.

The Yellow LED turns ON while the system checks the runway.

## Step 2: Runway Status Detection

The second ultrasonic sensor is used to check the runway.

- A distance greater than 20 cm indicates that the runway is considered clear.
- A distance at or below 20 cm indicates that the runway is occupied.
- A reading with no echo is treated by the current program as clear.

## Step 3: IR Priority Detection

The current program gives the IR sensor the highest priority.

When the IR sensor reads `LOW`, the system:

- Turns OFF the Green LED.
- Turns OFF the Yellow LED.
- Turns ON the Red LED.
- Activates the buzzer.
- Reports that the runway is occupied.

## Step 4: Decision and Indication

### Runway Clear

```text
Entry object detected
        ↓
Yellow LED ON
        ↓
Check runway sensor
        ↓
Runway clear
        ↓
Green LED ON
        ↓
SAFE TO PROCEED
```

### Runway Occupied

```text
Entry object detected
        ↓
Yellow LED ON
        ↓
Check runway sensor
        ↓
Runway occupied
        ↓
Red LED ON + Buzzer ON
        ↓
STOP / WARNING
```

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
