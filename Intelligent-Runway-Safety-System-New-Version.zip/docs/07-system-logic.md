# System Logic

The revised RFID-free logic is:

```text
START
  |
  v
Read Entry Ultrasonic
  |
  v
Read Runway Ultrasonic
  |
  v
Read IR Sensor
  |
  +---- IR detects object? ---- YES ----> RED + BUZZER
  |                                      |
  |                                      +----> Repeat
  |
  NO
  |
  v
Entry distance <= 20 cm?
  |
  +---- NO ----> LEDs OFF + Buzzer OFF
  |              |
  |              +----> Repeat
  |
  YES
  |
  v
YELLOW ON
  |
  v
Check Runway Sensor
  |
  +---- Runway clear ----> GREEN ON
  |
  +---- Runway occupied -> RED + BUZZER
  |
  v
Repeat
```

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
