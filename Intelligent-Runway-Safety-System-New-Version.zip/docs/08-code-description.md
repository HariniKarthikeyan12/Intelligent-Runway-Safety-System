# Code Description

The complete Arduino program is available at:

[`Arduino_Code/runway_safety.ino`](../Arduino_Code/runway_safety.ino)

## Main Program Sections

### Pin Definitions

The program assigns Arduino pins to:

- Two HC-SR04 ultrasonic sensors.
- One IR sensor.
- Green, Yellow, and Red LEDs.
- Buzzer.

### Distance Measurement

The `getDistance()` function triggers an ultrasonic sensor and converts the returned echo duration into distance in centimeters.

```cpp
float distance = duration * 0.0343 / 2;
```

If no echo is received within the timeout period, the function returns `-1`.

### Detection Threshold

```cpp
#define DETECTION_DISTANCE 20
```

The system uses 20 cm as its object-detection threshold.

### IR Priority

The current program checks the IR sensor before the entry-based decision logic. A `LOW` reading is treated as object detection.

### Serial Monitor

The program uses:

```cpp
Serial.begin(9600);
```

The Serial Monitor displays system state, sensor distances, and safety messages.

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
