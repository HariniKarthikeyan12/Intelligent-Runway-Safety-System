# Testing and Output

The current prototype can be tested by moving an object or hand toward the sensor zones.

## Test Cases

| Test condition | Expected indication |
|---|---|
| No object at entry | Green OFF, Yellow OFF, Red OFF, Buzzer OFF |
| Object detected at entry | Yellow ON while runway is checked |
| Runway clear after entry detection | Green ON |
| Runway occupied | Red ON + Buzzer ON |
| IR sensor detects an object | Red ON + Buzzer ON |

## Serial Monitor

The program outputs messages such as:

```text
DYNAMIC RUNWAY SAFETY CONTROL SYSTEM
SYSTEM READY
Move your hand toward ENTRY SENSOR
```

During detection, it reports entry distance, runway distance, runway status, LED status, and buzzer status.

[Back to Table of Contents](../TABLE_OF_CONTENTS.md)
